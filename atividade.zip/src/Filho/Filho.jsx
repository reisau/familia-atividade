import styled from "styled-components"

export const EstiloFilhoP = styled.p`
    display: flex;
    justify-content: center;

`
export const EstiloFilho = styled.div`
    background-color: aqua;
    height: 400px;
    width: 1000px;
    align-items:center;

`