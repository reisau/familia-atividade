import Neto from "../Neto/Neto"
import { EstiloFilhoP } from "./Filho.jsx"
import { EstiloFilho } from "./Filho.jsx"

function Filho(props) {
    return (
        <>
            <EstiloFilho>
                <div>
                    <EstiloFilhoP>
                        <p>Filho</p>
                    </EstiloFilhoP>
                    <Neto corProp={props.corProp}/>
                </div>
            </EstiloFilho>
        </>
    )
}

export default Filho