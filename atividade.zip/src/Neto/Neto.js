import Bisneto from "../Bisneto/Bisneto"
import { EstiloNeto, EstiloNetoP } from "./Neto.jsx"

function Neto(props) {
    return (
        <>
            <div>
                <EstiloNeto>
                    <EstiloNetoP>
                    <p>Neto</p>
                    </EstiloNetoP>
                    <Bisneto corProp={props.corProp}/>
                </EstiloNeto>
            </div>
        </>
    )
}

export default Neto