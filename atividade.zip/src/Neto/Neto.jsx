import styled from "styled-components"

export const EstiloNetoP = styled.p`
    display: flex;
    justify-content: center;

`

export const EstiloNeto = styled.div`
    background-color: pink;
    width: 500px;
    height: 200px;
    align-items: center;
    margin: auto;
`