import styled from "styled-components"

export const EstiloAppP = styled.p`
    margin-top: 10%;
    display:flex;
    justify-content: center;
`

