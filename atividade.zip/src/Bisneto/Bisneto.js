import { ButtonBisneto } from "./Bisneto.jsx"
import { EstiloBisnetoP } from "./Bisneto.jsx"
import { EstiloBisneto } from "./Bisneto.jsx"

function Bisneto(props) {
    return (
        <>
            <EstiloBisneto>
                <div>
                    <EstiloBisnetoP>
                        <p>Bisneto</p>
                    </EstiloBisnetoP>
                    <ButtonBisneto>
                    <button onClick={() => props.corProp("green")}>clique</button>
                    </ButtonBisneto>
                    
                </div>
            </EstiloBisneto>
        </>
    )
}

export default Bisneto