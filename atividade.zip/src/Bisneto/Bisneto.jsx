import styled from "styled-components"

export const EstiloBisnetoP = styled.p`
    text-align: center;
`
export const EstiloBisneto = styled.div`
    background-color: gold;
    height: 100px;
    width: 250px;
    margin: auto;
`

export const ButtonBisneto = styled.button`
    display: flex;
    justify-content: center;
    margin: auto;
`

