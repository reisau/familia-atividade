import Filho from "./Filho/Filho";
import { EstiloAppP } from "./App2.jsx";
import { useState } from "react";
import styled from "styled-components"


function App() {
  const [cor, setCor] = useState("purple")

  const EstiloApp = styled.div`
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: ${cor};
    height: 800px;`

  return (
    <EstiloApp>
      <div className="App">
        <EstiloAppP><p>App!!</p></EstiloAppP>
        <Filho corProp={setCor}/>
      </div>
    </EstiloApp>
  );
}

export default App;
